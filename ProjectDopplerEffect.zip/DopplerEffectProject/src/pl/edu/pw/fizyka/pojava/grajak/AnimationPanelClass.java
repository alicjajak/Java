package pl.edu.pw.fizyka.pojava.grajak;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.Image;

//Renata Grela

public class AnimationPanelClass extends JPanel implements ActionListener{  //Renata Grela
	ButtonsPanelClass btn;
	JButton animation;
	int xObserver=150;
	static int xSource=420;
	int xprev , xnext;
	int xprevR , xnextR;
	 //int r=0;
	static int [] r= new int[20];
	public static int [] circle= new int [20];
	
	 //int circle=150;
	static int i=0;
	int j=0;
	static int  VxObserver, VxSource;
	Image bikeRight= new ImageIcon("rower.png").getImage(); // obrazek udostepniony przez strone http://nonciclopedia.wikia.com/wiki/File:Bicicletta.gif
	Image bikeLeft= new ImageIcon("rower2.png").getImage();// obrazek udostepniony przez strone http://nonciclopedia.wikia.com/wiki/File:Bicicletta.gif
	Image ambulanceRight= new ImageIcon("karetka.png").getImage(); //obrazek udostepniony przez strone https://pl.seaicons.com/karetka-ikona-opieki-zdrowotnej/
	Image ambulanceLeft= new ImageIcon("karetka2.png").getImage(); //obrazek udostepniony przez strone https://pl.seaicons.com/karetka-ikona-opieki-zdrowotnej/
	
	int a=0;
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(xnext>=xprev) g.drawImage(ambulanceRight, xSource, 150, null);
		if(xprev>xnext)  g.drawImage(ambulanceLeft, xSource, 150, null);
		if(xnextR>=xprevR) g.drawImage(bikeRight, xObserver, 150, null);
		if(xprevR>xnextR)  g.drawImage(bikeLeft, xObserver, 150, null);
		for(int i=0; i<20;i++)
		g.drawOval(circle[i],170,r[i] ,r[i]);
	}
	
	public AnimationPanelClass() {
		this.setBackground(Color.white);
		for(int j=0; j<20; j++)
			r[j]=0;
		
		Timer t= new Timer(100,this);
		t.start();
		Timer t2= new Timer(1000,new M());
		t2.start();
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(RightPanelClass.running) {
			for(int j=0; j<20; j++) {
				
			r[j]+=MainGUI.rightPanel.l;}
			if(AnimationPanelClass.r[AnimationPanelClass.i]>200) AnimationPanelClass.r[AnimationPanelClass.i]=1;
			
			xprev=xSource;
			xprevR=xObserver;
			
			VxSource=MainGUI.buttonsPanel.sliderVsource.getValue();
			VxObserver=MainGUI.buttonsPanel.sliderVrecipient.getValue();
			
			if(xSource>900) xSource=-80;
			if(xSource<-80) xSource=900;
			if(xObserver>900) xObserver=-80;
			if(xObserver<-80) xObserver=900;
		
			xObserver+=VxObserver;
			xSource+=VxSource;
			
			xnext=xSource;
			xnextR=xObserver;
		
			repaint();
		}
		
	}
	
	
			
	}
 class M implements ActionListener{
//int i=0;
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(RightPanelClass.running) {
			
		if(AnimationPanelClass.i>=19) AnimationPanelClass.i=0;
		AnimationPanelClass.i++;
		//if(AnimationPanelClass.r[AnimationPanelClass.i]>200) AnimationPanelClass.r[AnimationPanelClass.i]=1;
		AnimationPanelClass.circle[AnimationPanelClass.i] = AnimationPanelClass.xSource+70 ;
		
	}
	}
	 
 }

