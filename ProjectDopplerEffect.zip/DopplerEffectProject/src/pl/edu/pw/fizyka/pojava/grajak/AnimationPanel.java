package pl.edu.pw.fizyka.pojava.grajak;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.Image;

public class AnimationPanel extends JPanel implements ActionListener{ //implements Runnable{ //Renata Grela
	ButtonsPanelClass btn;
	JButton animation;
	int xObserver=420, xSource=150;
	int VxObserver, VxSource;
	Image karetka= new ImageIcon("karetka.png").getImage(); //obrazek udostepniony przez strone https://pl.seaicons.com/karetka-ikona-opieki-zdrowotnej/
	Image rower= new ImageIcon("rower.png").getImage(); // obrazek udostepniony przez strone http://nonciclopedia.wikia.com/wiki/File:Bicicletta.gif
	//Thread thread;
	JLabel label;
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//g.fillOval(xObserver, 150, 30, 30);
		//g.setColor(Color.red);
		//g.fillOval(xSource, 150, 40, 40);
		g.drawImage(karetka, xSource, 150, null);
		g.drawImage(rower, xObserver, 150, null);
	}
	/*public AnimationPanelClass(ButtonsPanelClass butt) {
		btn=butt;
		animation = new JButton("Animacja");
		VxSource=btn.valVrecipient;
		VxObserver=btn.valVsource;
		//add(BorderLayout.SOUTH,animation);
		
		this.setBackground(Color.white);
	//	thread= new Thread(this);
	//	thread.start();
		animation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				VxSource=btn.valVrecipient;
				VxObserver=btn.valVsource;
				xObserver=xObserver+VxObserver;
				xSource= xSource+ VxSource;
				repaint();
				}
					
				
			
		});
		Timer t= new Timer(100,this);
		t.start();
	}*/
	public AnimationPanel(int Vxs,int Vxo) {
		VxSource=Vxs;
		VxObserver=Vxo;
		btn.sliderVrecipient.setPaintLabels(true);

        label = new JLabel();
        label.setIcon(new ImageIcon("rower.png"));
		this.setBackground(Color.white);			
		Timer t= new Timer(100,this);
		t.start();
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		xObserver=xObserver+btn.sliderVrecipient.getValue();
		xSource= xSource+ VxSource;
		//xObserver=xObserver+5;
		//xSource= xSource+3;
		repaint();
		
	}
	/*@Override
	public void run() {
		while(true)
		{
			xObserver=xObserver+VxObserver;
			xSource= xSource+ VxSource;
			//xObserver=xObserver+5;
			//xSource= xSource+5;
		repaint();
		
		try {
			Thread.sleep(200);
		}catch(InterruptedException e){
			System.out.println("Error");
		}
		
	}

	}*/			
	}

